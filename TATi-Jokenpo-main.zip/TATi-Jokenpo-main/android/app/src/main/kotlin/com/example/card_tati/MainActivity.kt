package com.example.card_tati

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
